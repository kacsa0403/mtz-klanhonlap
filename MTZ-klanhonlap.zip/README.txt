MTZ – Magyar Tank Zúzók klánhonlap
=====================================

Fájlok:
- index.html: reszponzív, egyoldalas honlap.

Gyors előnézet:
1. Nyisd meg az index.html fájlt böngészőben.
2. A mintatagokat és a szövegeket az index.html fájlban tudod átírni.
3. A jelentkezési űrlaphoz keresd meg a `CSERELD_LE_A_KAPCSOLATTARTO_EMAIL_CIMRE` szöveget a fájl alján, és cseréld a klán e-mail-címére.

Ingyenes publikálás GitHub Pages segítségével:
1. Hozz létre egy GitHub-fiókot a github.com oldalon.
2. Hozz létre egy új, nyilvános repository-t, például `mtz-klanhonlap` néven.
3. Töltsd fel az `index.html` fájlt a repository gyökerébe.
4. Repository → Settings → Pages.
5. Build and deployment: válaszd a Deploy from a branch lehetőséget, branch: `main`, folder: `/(root)`, majd Save.
6. Pár perc múlva a GitHub Pages megadja a publikus webcímet.

Fontos:
- A statisztikák helyén egyelőre szándékosan `—` szerepel; nem tüntetünk fel kitalált adatokat.
- A tagok nevei helykitöltők.
- A jelentkezési űrlap alapértelmezésben nem küld adatot sehova; a kapcsolattartó e-mail-cím beállítása után a látogató levelezőprogramját nyitja meg.
- A háttérképek külső Unsplash URL-ekről töltődnek be, így internetkapcsolat kell hozzájuk.
- A lap nem hivatalos Wargaming-oldal.
